import { Button } from "@/components/ui/button";
import { ChevronRight, Phone, Mail, MapPin, Zap, Shield, Percent, Clock, Users, Sparkles, ArrowRight } from "lucide-react";
import { useState } from "react";

/**
 * Design System: Minimalismo Corporativo Agressivo
 * Cores: Preto fosco (#0a0a0a), branco puro (#ffffff), vermelho racing (#d32f2f), cinza carbono (#2a2a2a)
 * Tipografia: Montserrat ExtraBold (display) + Inter (body)
 * Layout: Assimétrico, espaço negativo generoso, seções com altura variável
 */

// Carros alemães
const germanCars = [
  {
    name: "Porsche 911 Turbo S",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/porsche-911-turbo-s-66HSxdjm6jgkpz5R8T3VUV.webp",
    power: "650 cv",
    acceleration: "2.7s",
    price: "R$ 1.100.000",
  },
  {
    name: "BMW M8 Competition",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/bmw-m8-competition-82B2rzfxYiyXVaERViE986.webp",
    power: "625 cv",
    acceleration: "3.2s",
    price: "R$ 950.000",
  },
  {
    name: "Mercedes-AMG GT R",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/mercedes-amg-gt-r-ZUvq6c2fCQeWhmKE5VYCSR.webp",
    power: "585 cv",
    acceleration: "3.5s",
    price: "R$ 1.050.000",
  },
  {
    name: "Audi R8 V10",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/audi-r8-v10-TRjGvWnS59v7T4UrgJ8ExG.webp",
    power: "620 cv",
    acceleration: "3.2s",
    price: "R$ 1.000.000",
  },
  {
    name: "Porsche 911 GT2 RS",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/porsche-911-gt2-rs-hXwcqp6LG6S8BCeHxwgSx7.webp",
    power: "700 cv",
    acceleration: "2.8s",
    price: "R$ 1.350.000",
  },
];

// Carros italianos
const italianCars = [
  {
    name: "Ferrari F8 Tributo",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/ferrari-f8-tributo-iCS46LdSogUjpkoQBrmuAP.webp",
    power: "720 cv",
    acceleration: "2.9s",
    price: "R$ 1.600.000",
  },
  {
    name: "Lamborghini Revuelto",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/lamborghini-revuelto-UHabuZG7Fe7GQwpm7PXXnN.webp",
    power: "1001 cv",
    acceleration: "2.5s",
    price: "R$ 2.200.000",
  },
  {
    name: "Maserati MC20",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/maserati-mc20-4MieKuGfJuXyqfG3umbdyZ.webp",
    power: "630 cv",
    acceleration: "2.9s",
    price: "R$ 1.400.000",
  },
  {
    name: "Pagani Huayra",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/pagani-huayra-BtPhfVUDroMbX4GmEo3tgd.webp",
    power: "730 cv",
    acceleration: "2.8s",
    price: "R$ 2.000.000",
  },
  {
    name: "Bugatti Chiron",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/bugatti-chiron-S5PdZ7HMS5NBRMwoGXbGiS.webp",
    power: "1500 cv",
    acceleration: "2.4s",
    price: "R$ 3.500.000",
  },
];

// Carros americanos
const americanCars = [
  {
    name: "Chevrolet Corvette C8 Z06",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/corvette-c8-z06-dwECkE7rDkPa9PgdDUyCyf.webp",
    power: "670 cv",
    acceleration: "2.6s",
    price: "R$ 1.200.000",
  },
  {
    name: "Dodge Viper ACR",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/dodge-viper-acr-4eCrMc9pFsXnriJSjKnqjW.webp",
    power: "645 cv",
    acceleration: "3.0s",
    price: "R$ 1.100.000",
  },
  {
    name: "Ford GT",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/ford-gt-JNXrP9U37kLbeuW4rq5mgn.webp",
    power: "660 cv",
    acceleration: "2.8s",
    price: "R$ 1.450.000",
  },
  {
    name: "Lamborghini Aventador SVJ",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/lamborghini-aventador-svj-cMThaJ5Gxjthtzz797RiRw.webp",
    power: "770 cv",
    acceleration: "2.8s",
    price: "R$ 1.750.000",
  },
  {
    name: "Hennessey Venom F5",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/hennessey-venom-f5-o2t2mg6TbAJsNdZt4fbHXP.webp",
    power: "1817 cv",
    acceleration: "2.0s",
    price: "R$ 2.800.000",
  },
];

const differentials = [
  {
    icon: Shield,
    title: "Procedência Impecável",
    description: "Veículos com laudo cautelar e histórico completo verificado",
  },
  {
    icon: Zap,
    title: "Revisão Incluída",
    description: "Manutenção completa e detalhamento profissional antes da entrega",
  },
  {
    icon: Percent,
    title: "Melhores Taxas",
    description: "Financiamento e consórcio com as condições mais competitivas",
  },
  {
    icon: Clock,
    title: "Garantia Estendida",
    description: "Cobertura de até 24 meses em peças e mão de obra",
  },
  {
    icon: Users,
    title: "Atendimento VIP",
    description: "Consultoria personalizada 100% dedicada ao seu sonho",
  },
  {
    icon: Sparkles,
    title: "Troca na Hora",
    description: "Avaliação imediata do seu veículo com proposta em tempo real",
  },
];

const testimonials = [
  {
    name: "Carlos Mendes",
    city: "São Paulo",
    car: "Porsche 911 Turbo S",
    text: "Experiência impecável do início ao fim. Equipe profissional, carros de qualidade excepcional.",
    rating: 5,
  },
  {
    name: "Fernanda Costa",
    city: "Curitiba",
    car: "Ferrari F8 Tributo",
    text: "Melhor decisão que tomei. Atendimento VIP, financiamento perfeito, carro dos sonhos.",
    rating: 5,
  },
  {
    name: "Roberto Silva",
    city: "Rio de Janeiro",
    car: "Lamborghini Revuelto",
    text: "Profissionalismo de nível internacional. Recomendo para qualquer entusiasta.",
    rating: 5,
  },
];

const steps = [
  { number: 1, title: "Escolha seu sonho", description: "Explore nosso catálogo exclusivo" },
  { number: 2, title: "Agende test-drive", description: "Sinta a adrenalina na pista" },
  { number: 3, title: "Proposta personalizada", description: "Condições sob medida para você" },
  { number: 4, title: "Financiamento flexível", description: "Taxas competitivas garantidas" },
  { number: 5, title: "Dirija seu superesportivo", description: "Realize seu sonho agora" },
];

interface CarCardProps {
  car: {
    name: string;
    image: string;
    power: string;
    acceleration: string;
    price: string;
  };
}

const CarCard: React.FC<CarCardProps> = ({ car }) => (
  <div className="group cursor-pointer">
    <div className="relative overflow-hidden rounded-lg mb-6 h-80 bg-gray-900">
      <img
        src={car.image}
        alt={car.name}
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
      />
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
    </div>
    <h3 className="text-xl font-black font-['Montserrat'] mb-3">{car.name}</h3>
    <div className="grid grid-cols-3 gap-4 mb-6 pb-6 border-b border-gray-700">
      <div>
        <div className="text-red-600 font-bold text-xs">POTÊNCIA</div>
        <div className="text-base font-bold">{car.power}</div>
      </div>
      <div>
        <div className="text-red-600 font-bold text-xs">0-100 KM/H</div>
        <div className="text-base font-bold">{car.acceleration}</div>
      </div>
      <div>
        <div className="text-red-600 font-bold text-xs">PREÇO</div>
        <div className="text-base font-bold">{car.price}</div>
      </div>
    </div>
    <button className="w-full btn-accent text-center py-3 text-sm">
      Mais Informações
    </button>
  </div>
);

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    whatsapp: "",
    email: "",
    model: "",
    message: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Obrigado! Entraremos em contato em breve.");
    setFormData({ name: "", whatsapp: "", email: "", model: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-white text-black font-['Inter']">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200">
        <div className="container flex items-center justify-between h-20">
          <div className="text-2xl font-black font-['Montserrat'] tracking-tighter">
            Elite <span className="text-red-600">Performance</span>
          </div>
          <div className="hidden md:flex gap-8 items-center">
            <a href="#carros" className="hover:text-red-600 transition-colors">
              Carros
            </a>
            <a href="#diferenciais" className="hover:text-red-600 transition-colors">
              Diferenciais
            </a>
            <a href="#contato" className="hover:text-red-600 transition-colors">
              Contato
            </a>
            <a href="https://wa.me/5541999999999" className="btn-accent text-sm py-2 px-4">
              WhatsApp
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-0 min-h-screen flex items-center overflow-hidden">
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/hero-supercarro-noite-Fe2nCGFAi4kBEWRm3hUmqr.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            opacity: 0.4,
          }}
        />
        <div className="absolute inset-0 bg-black/40 z-0" />

        <div className="container relative z-10 flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-1/2 space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-7xl font-black font-['Montserrat'] leading-tight tracking-tighter">
                Sinta a <span className="text-red-600">adrenalina</span>
              </h1>
              <h2 className="text-3xl md:text-5xl font-black font-['Montserrat'] text-gray-400 leading-tight">
                Viva o extraordinário
              </h2>
            </div>

            <p className="text-lg md:text-xl text-gray-600 max-w-lg leading-relaxed">
              Supercarros e esportivos de alto desempenho selecionados com rigor. Exclusividade, performance e emoção em cada curva.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button className="btn-primary">
                Agendar Test-Drive <ArrowRight className="inline ml-2 w-5 h-5" />
              </button>
              <button className="btn-secondary">
                Ver Catálogo
              </button>
            </div>

            <div className="pt-8 border-t border-gray-300 flex gap-12">
              <div>
                <div className="text-3xl font-black font-['Montserrat'] text-red-600">50+</div>
                <div className="text-sm text-gray-600">Supercarros em estoque</div>
              </div>
              <div>
                <div className="text-3xl font-black font-['Montserrat'] text-red-600">1000+</div>
                <div className="text-sm text-gray-600">Clientes satisfeitos</div>
              </div>
              <div>
                <div className="text-3xl font-black font-['Montserrat'] text-red-600">15 min</div>
                <div className="text-sm text-gray-600">Resposta garantida</div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 relative h-96 md:h-full min-h-96">
            <div
              className="absolute inset-0 rounded-lg overflow-hidden"
              style={{
                backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663388053050/HiYM7BvzNQ2qioptxf57bb/hero-background-abstract-cEG5C54oFoYdD4gDwSdtqe.webp')",
                backgroundSize: "cover",
                backgroundPosition: "center",
              }}
            />
          </div>
        </div>
      </section>

      {/* Featured Cars Section - German Cars */}
      <section id="carros" className="py-24 bg-black text-white">
        <div className="container">
          <div className="mb-16">
            <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-4">
              Supercarros <span className="text-red-600">Alemães</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl">
              Engenharia de precisão, performance alemã. Porsche, BMW, Mercedes e Audi em sua forma mais extrema.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            {germanCars.map((car, idx) => (
              <CarCard key={idx} car={car} />
            ))}
          </div>
        </div>
      </section>

      {/* Italian Cars Section */}
      <section className="py-24 bg-gray-900 text-white">
        <div className="container">
          <div className="mb-16">
            <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-4">
              Supercarros <span className="text-red-600">Italianos</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl">
              Paixão, design e adrenalina. Ferrari, Lamborghini, Maserati e Pagani - o melhor da Itália.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            {italianCars.map((car, idx) => (
              <CarCard key={idx} car={car} />
            ))}
          </div>
        </div>
      </section>

      {/* American Cars Section */}
      <section className="py-24 bg-black text-white">
        <div className="container">
          <div className="mb-16">
            <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-4">
              Supercarros <span className="text-red-600">Americanos</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl">
              Potência bruta e inovação. Corvette, Ford e Hennessey - o poder americano em sua essência.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            {americanCars.map((car, idx) => (
              <CarCard key={idx} car={car} />
            ))}
          </div>
        </div>
      </section>

      {/* Differentials Section */}
      <section id="diferenciais" className="py-24 bg-white">
        <div className="container">
          <div className="mb-16">
            <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-4">
              Por que comprar <span className="text-red-600">conosco?</span>
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl">
              Mais que carros, oferecemos uma experiência de luxo e confiança incomparável.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {differentials.map((diff, idx) => {
              const Icon = diff.icon;
              return (
                <div key={idx} className="group p-8 border border-gray-200 rounded-lg hover:border-red-600 hover:shadow-lg transition-all duration-300">
                  <Icon className="w-12 h-12 text-red-600 mb-6 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="text-xl font-bold font-['Montserrat'] mb-3">{diff.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{diff.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-gray-50">
        <div className="container">
          <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-16">
            Nossos <span className="text-red-600">Clientes Felizes</span>
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <div key={idx} className="bg-white p-8 rounded-lg border border-gray-200">
                <div className="flex gap-1 mb-4">
                  {Array(testimonial.rating)
                    .fill(0)
                    .map((_, i) => (
                      <span key={i} className="text-red-600 text-lg">
                        ★
                      </span>
                    ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed italic">"{testimonial.text}"</p>
                <div className="border-t border-gray-200 pt-4">
                  <div className="font-bold font-['Montserrat']">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.car}</div>
                  <div className="text-sm text-red-600">{testimonial.city}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Purchase Process Section */}
      <section className="py-24 bg-black text-white">
        <div className="container">
          <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-16">
            Processo <span className="text-red-600">Simples</span>
          </h2>

          <div className="grid md:grid-cols-5 gap-4 md:gap-0">
            {steps.map((step, idx) => (
              <div key={idx} className="relative">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-4 font-black font-['Montserrat'] text-2xl">
                    {step.number}
                  </div>
                  <h3 className="font-bold font-['Montserrat'] mb-2">{step.title}</h3>
                  <p className="text-sm text-gray-400">{step.description}</p>
                </div>
                {idx < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-[calc(50%+32px)] right-[-50%] h-0.5 bg-red-600" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="contato" className="py-24 bg-white">
        <div className="container max-w-3xl">
          <div className="mb-12 text-center">
            <h2 className="text-5xl md:text-6xl font-black font-['Montserrat'] mb-4">
              Dê o próximo passo rumo à sua <span className="text-red-600">máquina dos sonhos</span>
            </h2>
            <p className="text-gray-600 text-lg">Respondemos em até 15 minutos</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 bg-gray-50 p-8 rounded-lg border border-gray-200">
            <div className="grid md:grid-cols-2 gap-6">
              <input
                type="text"
                name="name"
                placeholder="Seu nome"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600 transition-colors"
              />
              <input
                type="tel"
                name="whatsapp"
                placeholder="WhatsApp"
                value={formData.whatsapp}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600 transition-colors"
              />
            </div>

            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleInputChange}
              required
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600 transition-colors"
            />

            <select
              name="model"
              value={formData.model}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600 transition-colors"
            >
              <option value="">Modelo de interesse</option>
              <option value="porsche">Porsche 911 Turbo S</option>
              <option value="bmw">BMW M8 Competition</option>
              <option value="mercedes">Mercedes-AMG GT R</option>
              <option value="audi">Audi R8 V10</option>
              <option value="porsche-gt2">Porsche 911 GT2 RS</option>
              <option value="ferrari">Ferrari F8 Tributo</option>
              <option value="lamborghini">Lamborghini Revuelto</option>
              <option value="maserati">Maserati MC20</option>
              <option value="pagani">Pagani Huayra</option>
              <option value="bugatti">Bugatti Chiron</option>
              <option value="corvette">Chevrolet Corvette C8 Z06</option>
              <option value="dodge">Dodge Viper ACR</option>
              <option value="ford">Ford GT</option>
              <option value="aventador">Lamborghini Aventador SVJ</option>
              <option value="hennessey">Hennessey Venom F5</option>
              <option value="outro">Outro modelo</option>
            </select>

            <textarea
              name="message"
              placeholder="Mensagem (opcional)"
              value={formData.message}
              onChange={handleInputChange}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600 transition-colors resize-none"
            />

            <div className="flex flex-col sm:flex-row gap-4">
              <button type="submit" className="btn-accent flex-1 py-4 text-lg font-bold">
                Quero Agendar Test-Drive
              </button>
              <button type="button" className="btn-primary flex-1 py-4 text-lg font-bold">
                Receber Proposta Agora
              </button>
            </div>

            <p className="text-xs text-gray-500 text-center">
              Seus dados estão seguros. Respeitamos sua privacidade. Respondemos em até 15 minutos.
            </p>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div>
              <h3 className="text-2xl font-black font-['Montserrat'] mb-4">
                Elite <span className="text-red-600">Performance</span>
              </h3>
              <p className="text-gray-400">Supercarros de luxo e alto desempenho</p>
            </div>

            <div>
              <h4 className="font-bold font-['Montserrat'] mb-4">Contato</h4>
              <div className="space-y-3 text-gray-400">
                <a href="https://wa.me/5541999999999" className="flex items-center gap-2 hover:text-red-600 transition-colors">
                  <Phone className="w-4 h-4" /> (41) 99999-9999
                </a>
                <a href="mailto:contato@eliteperformance.com" className="flex items-center gap-2 hover:text-red-600 transition-colors">
                  <Mail className="w-4 h-4" /> contato@eliteperformance.com
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-bold font-['Montserrat'] mb-4">Localização</h4>
              <div className="flex items-start gap-2 text-gray-400">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                <div>
                  <div>Curitiba - PR</div>
                  <div className="text-sm">Atendimento Nacional</div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-bold font-['Montserrat'] mb-4">Links Rápidos</h4>
              <div className="space-y-2 text-gray-400">
                <a href="#carros" className="block hover:text-red-600 transition-colors">
                  Estoque Completo
                </a>
                <a href="#" className="block hover:text-red-600 transition-colors">
                  Financiamento
                </a>
                <a href="#" className="block hover:text-red-600 transition-colors">
                  Sobre Nós
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>&copy; 2026 Elite Performance Cars. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
